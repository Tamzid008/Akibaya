import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import crypto from "crypto";

export async function registerRoutes(app: Express): Promise<Server> {
  // ImageKit authentication endpoint
  app.post("/api/imagekit-auth", async (req, res) => {
    try {
      const privateKey = process.env.IMAGEKIT_PRIVATE_KEY;
      if (!privateKey) {
        return res.status(500).json({ error: "ImageKit private key not configured" });
      }

      const token = crypto.randomUUID();
      const expire = Math.floor(Date.now() / 1000) + 2400; // 40 minutes from now
      const signature = crypto
        .createHmac("sha1", privateKey)
        .update(token + expire)
        .digest("hex");

      res.json({
        token,
        expire,
        signature,
      });
    } catch (error) {
      console.error("ImageKit auth error:", error);
      res.status(500).json({ error: "Failed to generate ImageKit authentication" });
    }
  });

  // Order submission endpoint
  app.post("/api/orders", async (req, res) => {
    try {
      const orderSchema = z.object({
        imageUrl: z.string().url(),
        productType: z.enum(["Wallpaper", "Sticker"]),
        length: z.number().positive(),
        width: z.number().positive(),
        unit: z.enum(["Feet", "Inch"]),
        quantity: z.number().int().positive(),
        totalPrice: z.number().int().positive(),
        name: z.string().min(1),
        phone: z.string().min(10),
        email: z.string().email(),
        address: z.string().min(5),
        notes: z.string().optional(),
      });

      const orderData = orderSchema.parse(req.body);

      // Submit to Google Sheets
      const googleSheetsPayload = {
        imageUrl: orderData.imageUrl,
        productType: orderData.productType,
        length: orderData.length,
        width: orderData.width,
        unit: orderData.unit,
        quantity: orderData.quantity,
        totalPrice: orderData.totalPrice,
        name: orderData.name,
        phone: orderData.phone,
        email: orderData.email,
        address: orderData.address,
        notes: orderData.notes || "",
      };

      const response = await fetch(
        "https://script.google.com/macros/s/AKfycbzbatmgIoS1oXpeDyK1M_isZz7wI72FGeM8w7Bn7dcWm4ktE8os6yxyxQ10S5EeG6g/exec",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(googleSheetsPayload),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to submit to Google Sheets");
      }

      res.json({ success: true, message: "Order submitted successfully" });
    } catch (error) {
      console.error("Order submission error:", error);
      res.status(400).json({ 
        success: false, 
        message: error instanceof Error ? error.message : "Failed to submit order" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
