// Storage interface for potential future use
// This project directly submits to Google Sheets via API
export interface IStorage {
  // Future storage methods can be added here
}

export class MemStorage implements IStorage {
  constructor() {
    // Empty constructor for now
  }
}

export const storage = new MemStorage();
