export const IMAGEKIT_CONFIG = {
  publicKey: import.meta.env.VITE_IMAGEKIT_PUBLIC_KEY || "public_b94XPXHzaEoi3zTpjQImG+pB34A=",
  urlEndpoint: import.meta.env.VITE_IMAGEKIT_URL_ENDPOINT || "https://ik.imagekit.io/sitelagbe",
  uploadEndpoint: "https://upload.imagekit.io/api/v1/files/upload",
};

export interface ImageKitUploadResponse {
  url: string;
  fileId: string;
  name: string;
  size: number;
  filePath: string;
}

export async function uploadToImageKit(file: File): Promise<ImageKitUploadResponse> {
  // Get authentication from backend since private key should not be exposed to frontend
  const authResponse = await fetch('/api/imagekit-auth', {
    method: 'POST',
  });

  if (!authResponse.ok) {
    throw new Error('Failed to get authentication for ImageKit');
  }

  const authData = await authResponse.json();

  const formData = new FormData();
  formData.append('file', file);
  formData.append('publicKey', IMAGEKIT_CONFIG.publicKey);
  formData.append('signature', authData.signature);
  formData.append('expire', authData.expire.toString());
  formData.append('token', authData.token);
  formData.append('fileName', `akibaya_${Date.now()}_${file.name}`);
  formData.append('folder', '/Akibaya_anime_accessories_website');

  const response = await fetch(IMAGEKIT_CONFIG.uploadEndpoint, {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('ImageKit upload error:', {
      status: response.status,
      statusText: response.statusText,
      errorText: errorText
    });
    throw new Error(`Failed to upload image to ImageKit: ${response.status} ${errorText}`);
  }

  return response.json();
}

export function validateImageFile(file: File): { valid: boolean; error?: string } {
  // Check file type
  if (!file.type.match(/^image\/(jpeg|png|webp)$/)) {
    return {
      valid: false,
      error: 'Please upload a valid image file (JPG, PNG, or WebP)',
    };
  }

  // Check file size (10MB max)
  if (file.size > 10 * 1024 * 1024) {
    return {
      valid: false,
      error: 'File size must be less than 10MB',
    };
  }

  return { valid: true };
}
