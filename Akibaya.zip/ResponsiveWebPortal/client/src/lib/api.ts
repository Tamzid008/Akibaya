import { apiRequest } from "./queryClient";

export interface OrderSubmission {
  imageUrl: string;
  productType: 'Wallpaper' | 'Sticker';
  length: number;
  width: number;
  unit: 'Feet' | 'Inch';
  quantity: number;
  totalPrice: number;
  name: string;
  phone: string;
  email: string;
  address: string;
  notes?: string;
}

export async function submitOrder(orderData: OrderSubmission) {
  const response = await apiRequest("POST", "/api/orders", orderData);
  return response.json();
}
