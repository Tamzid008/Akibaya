import { ExternalLink, Heart } from "lucide-react";
import { FaWhatsapp, FaFacebook, FaFacebookMessenger, FaEnvelope } from "react-icons/fa";

export default function Footer() {
  const contactLinks = [
    {
      href: "https://wa.me/+8801629857483",
      icon: FaWhatsapp,
      label: "WhatsApp",
      hoverColor: "hover:text-akibaya-neon-pink",
    },
    {
      href: "https://www.facebook.com/SiteLagbeBD/",
      icon: FaFacebook,
      label: "Facebook",
      hoverColor: "hover:text-akibaya-cyan-blue",
    },
    {
      href: "https://www.messenger.com/e2ee/t/7775732315795055",
      icon: FaFacebookMessenger,
      label: "Messenger",
      hoverColor: "hover:text-akibaya-neon-pink",
    },
    {
      href: "mailto:akibaya442@gmail.com",
      icon: FaEnvelope,
      label: "Email",
      hoverColor: "hover:text-akibaya-cyan-blue",
    },
  ];

  return (
    <footer className="bg-akibaya-dark-grey-blue py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <img
              src="https://ik.imagekit.io/sitelagbe/Akibaya:%20anime%20accessories%20website./Website%20logo/Explosive%20AKIBAYA%20Energy%20Burst.png?updatedAt=1748256705630"
              alt="Akibaya Logo"
              className="h-8 w-auto mb-2"
            />
            <p className="text-akibaya-soft-grey">Bangladesh's first anime wallpaper brand</p>
          </div>

          <div className="flex space-x-6">
            {contactLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className={`text-akibaya-soft-grey ${link.hoverColor} transition-colors duration-300`}
                aria-label={link.label}
              >
                <link.icon className="text-2xl" />
              </a>
            ))}
          </div>
        </div>

        <div className="border-t border-akibaya-dark-indigo mt-8 pt-8 text-center">
          <p className="text-akibaya-soft-grey flex items-center justify-center gap-2">
            &copy; 2024 Akibaya. Made with <Heart className="h-4 w-4 text-akibaya-neon-pink" /> for anime fans in Bangladesh.
          </p>
        </div>
      </div>
    </footer>
  );
}
