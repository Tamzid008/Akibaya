import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import { 
  Image, 
  Ruler, 
  Truck, 
  Star, 
  Flag, 
  Rocket,
  Check,
  ChevronDown,
  Wallpaper,
  Sticker
} from "lucide-react";

export default function Home() {
  const features = [
    {
      icon: Image,
      title: "Custom Designs",
      description: "Upload your favorite anime artwork and we'll transform it into stunning wallpapers and stickers with perfect quality.",
      hoverColor: "group-hover:text-akibaya-cyan-blue",
      borderColor: "hover:border-akibaya-neon-pink/30",
    },
    {
      icon: Ruler,
      title: "Any Size",
      description: "From small stickers to wall-covering prints. Choose your dimensions and we'll make it happen with precision.",
      hoverColor: "group-hover:text-akibaya-neon-pink",
      borderColor: "hover:border-akibaya-cyan-blue/30",
    },
    {
      icon: Truck,
      title: "Fast Delivery",
      description: "Made in Bangladesh with love. Quick turnaround times and reliable delivery to bring anime to your space.",
      hoverColor: "group-hover:text-akibaya-cyan-blue",
      borderColor: "hover:border-akibaya-neon-pink/30",
    },
  ];

  const values = [
    {
      icon: Star,
      title: "High-Quality Designs",
      description: "Every piece is crafted with meticulous attention to detail, ensuring your favorite anime characters look their absolute best.",
      color: "text-akibaya-neon-pink",
      hoverColor: "group-hover:text-akibaya-cyan-blue",
      borderColor: "hover:border-akibaya-neon-pink/50",
    },
    {
      icon: Flag,
      title: "Made in Bangladesh",
      description: "Proudly supporting local craftsmanship while bringing world-class anime art to Bangladeshi fans.",
      color: "text-akibaya-cyan-blue",
      hoverColor: "group-hover:text-akibaya-neon-pink",
      borderColor: "hover:border-akibaya-cyan-blue/50",
    },
    {
      icon: Rocket,
      title: "Delivered with Hype",
      description: "Fast, reliable delivery service that gets your anime dreams to your doorstep with the excitement they deserve.",
      color: "text-akibaya-neon-pink",
      hoverColor: "group-hover:text-akibaya-cyan-blue",
      borderColor: "hover:border-akibaya-neon-pink/50",
    },
  ];

  const wallpaperFeatures = [
    "High-quality printing",
    "Custom dimensions",
    "Durable materials",
    "Easy installation",
  ];

  const stickerFeatures = [
    "Waterproof vinyl",
    "Perfect for laptops",
    "Vibrant colors",
    "Easy to apply",
  ];

  return (
    <div className="min-h-screen bg-akibaya-dark-indigo text-white">
      <Navbar />

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center relative overflow-hidden pt-16">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-32 h-32 bg-akibaya-neon-pink/10 rounded-full blur-xl animate-float"></div>
          <div className="absolute bottom-20 right-10 w-48 h-48 bg-akibaya-cyan-blue/10 rounded-full blur-xl animate-float [animation-delay:2s]"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-r from-akibaya-neon-pink/5 to-akibaya-cyan-blue/5 rounded-full blur-3xl"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center animate-slide-up">
            {/* Tagline */}
            <p className="text-akibaya-cyan-blue font-orbitron text-lg md:text-xl mb-6 tracking-wide">
              From Senpai to Shonen — We've Got Your Walls Covered
            </p>

            {/* Main Hook Message */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-orbitron font-bold mb-8 leading-tight">
              <span className="gradient-text-akibaya">
                Summon Your Space.
              </span>
              <br />
              <span className="text-white">Dominate Your Wall.</span>
              <br />
              <span className="bg-gradient-to-r from-akibaya-cyan-blue to-akibaya-neon-pink bg-clip-text text-transparent">
                Rule Like a Main Character.
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-xl md:text-2xl text-akibaya-soft-grey mb-12 max-w-3xl mx-auto leading-relaxed">
              Wallpapers, Stickers & Manga made for{" "}
              <span className="text-akibaya-neon-pink font-semibold">true anime believers</span>.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link href="/order">
                <Button className="group relative px-12 py-4 gradient-bg-akibaya rounded-full font-orbitron font-bold text-lg text-white hover:shadow-2xl hover:shadow-primary/50 transition-all duration-500 transform hover:scale-105 animate-glow">
                  <span className="relative z-10">Start Your Order</span>
                  <div className="absolute inset-0 rounded-full bg-gradient-to-r from-akibaya-cyan-blue to-akibaya-neon-pink opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                </Button>
              </Link>

              <Link href="/about">
                <Button
                  variant="outline"
                  className="px-8 py-4 border-2 border-akibaya-cyan-blue text-akibaya-cyan-blue rounded-full font-semibold hover:bg-akibaya-cyan-blue hover:text-akibaya-dark-indigo transition-all duration-300 transform hover:scale-105"
                >
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronDown className="text-akibaya-soft-grey text-2xl" />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-akibaya-dark-grey-blue/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-4 gradient-text-akibaya">
              Why Choose Akibaya?
            </h2>
            <p className="text-akibaya-soft-grey text-lg max-w-2xl mx-auto">
              Bangladesh's first dedicated anime wallpaper brand, crafted by fans for fans.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card
                key={index}
                className={`bg-akibaya-dark-grey-blue/80 border-akibaya-dark-grey-blue ${feature.borderColor} hover:bg-akibaya-dark-grey-blue transition-all duration-300 group transform hover:scale-105`}
              >
                <CardContent className="p-8">
                  <feature.icon className={`text-akibaya-neon-pink text-4xl mb-4 ${feature.hoverColor} transition-colors duration-300`} />
                  <h3 className="text-xl font-orbitron font-semibold mb-3 text-white">
                    {feature.title}
                  </h3>
                  <p className="text-akibaya-soft-grey leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-4 text-white">
              Simple, Transparent Pricing
            </h2>
            <p className="text-akibaya-soft-grey text-lg">
              No hidden fees. Just great anime prints at honest prices.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Wallpaper Pricing */}
            <Card className="bg-gradient-to-br from-akibaya-dark-grey-blue to-akibaya-dark-grey-blue/50 border-akibaya-neon-pink/20 hover:border-akibaya-neon-pink/50 transition-all duration-300">
              <CardContent className="p-8">
                <Wallpaper className="text-akibaya-neon-pink text-3xl mb-4" />
                <h3 className="text-2xl font-orbitron font-bold mb-2 text-white">Wallpapers</h3>
                <div className="text-3xl font-bold text-akibaya-neon-pink mb-4">
                  ৳60 <span className="text-lg text-akibaya-soft-grey font-normal">per sq ft</span>
                </div>
                <ul className="text-akibaya-soft-grey space-y-2">
                  {wallpaperFeatures.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <Check className="text-akibaya-cyan-blue mr-2 h-4 w-4" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Sticker Pricing */}
            <Card className="bg-gradient-to-br from-akibaya-dark-grey-blue to-akibaya-dark-grey-blue/50 border-akibaya-cyan-blue/20 hover:border-akibaya-cyan-blue/50 transition-all duration-300">
              <CardContent className="p-8">
                <Sticker className="text-akibaya-cyan-blue text-3xl mb-4" />
                <h3 className="text-2xl font-orbitron font-bold mb-2 text-white">Stickers</h3>
                <div className="text-3xl font-bold text-akibaya-cyan-blue mb-4">
                  ৳20 <span className="text-lg text-akibaya-soft-grey font-normal">per sq inch</span>
                </div>
                <ul className="text-akibaya-soft-grey space-y-2">
                  {stickerFeatures.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <Check className="text-akibaya-neon-pink mr-2 h-4 w-4" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-akibaya-dark-grey-blue/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-4 text-white">
              What We Stand For
            </h2>
            <p className="text-akibaya-soft-grey text-lg">Our commitment to the anime community</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center group">
                <Card className={`bg-akibaya-dark-grey-blue/80 border-akibaya-dark-grey-blue ${value.borderColor} transition-all duration-300 transform hover:scale-105`}>
                  <CardContent className="p-8">
                    <value.icon className={`${value.color} text-4xl mb-4 ${value.hoverColor} transition-colors duration-300`} />
                    <h3 className="text-xl font-orbitron font-semibold mb-3 text-white">
                      {value.title}
                    </h3>
                    <p className="text-akibaya-soft-grey leading-relaxed">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 bg-gradient-to-r from-akibaya-dark-grey-blue to-akibaya-dark-indigo">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-6 text-white">
            Ready to Transform Your Space?
          </h2>
          <p className="text-xl text-akibaya-soft-grey mb-8 leading-relaxed">
            Join the anime revolution. Upload your favorite artwork and let us bring it to life on your walls.
          </p>
          <Link href="/order">
            <Button className="px-12 py-4 gradient-bg-akibaya rounded-full font-orbitron font-bold text-lg text-white hover:shadow-2xl hover:shadow-primary/50 transition-all duration-500 transform hover:scale-105">
              Start Your Order Now
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
