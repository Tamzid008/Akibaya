import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import { Heart, Star, Flag, Rocket, ExternalLink } from "lucide-react";
import { FaWhatsapp, FaFacebook, FaFacebookMessenger, FaEnvelope } from "react-icons/fa";

export default function About() {
  const values = [
    {
      icon: Star,
      title: "High-Quality Designs",
      description: "Every piece is crafted with meticulous attention to detail, ensuring your favorite anime characters look their absolute best.",
      color: "text-akibaya-neon-pink",
      hoverColor: "group-hover:text-akibaya-cyan-blue",
      borderColor: "hover:border-akibaya-neon-pink/50",
    },
    {
      icon: Flag,
      title: "Made in Bangladesh",
      description: "Proudly supporting local craftsmanship while bringing world-class anime art to Bangladeshi fans.",
      color: "text-akibaya-cyan-blue",
      hoverColor: "group-hover:text-akibaya-neon-pink",
      borderColor: "hover:border-akibaya-cyan-blue/50",
    },
    {
      icon: Rocket,
      title: "Delivered with Hype",
      description: "Fast, reliable delivery service that gets your anime dreams to your doorstep with the excitement they deserve.",
      color: "text-akibaya-neon-pink",
      hoverColor: "group-hover:text-akibaya-cyan-blue",
      borderColor: "hover:border-akibaya-neon-pink/50",
    },
  ];

  const contactLinks = [
    {
      href: "https://wa.me/+8801629857483",
      icon: FaWhatsapp,
      label: "WhatsApp",
      title: "WhatsApp",
      description: "Quick responses and instant support",
      color: "text-akibaya-neon-pink",
      bgColor: "bg-akibaya-neon-pink/20",
    },
    {
      href: "https://www.facebook.com/SiteLagbeBD/",
      icon: FaFacebook,
      label: "Facebook",
      title: "Facebook",
      description: "Follow us for updates and community content",
      color: "text-akibaya-cyan-blue",
      bgColor: "bg-akibaya-cyan-blue/20",
    },
    {
      href: "mailto:akibaya442@gmail.com",
      icon: FaEnvelope,
      label: "Email",
      title: "Email",
      description: "For detailed inquiries and support",
      color: "text-akibaya-neon-pink",
      bgColor: "bg-akibaya-neon-pink/20",
    },
    {
      href: "https://www.messenger.com/e2ee/t/7775732315795055",
      icon: FaFacebookMessenger,
      label: "Messenger",
      title: "Messenger",
      description: "Chat with us directly on Facebook",
      color: "text-akibaya-cyan-blue",
      bgColor: "bg-akibaya-cyan-blue/20",
    },
  ];

  return (
    <div className="min-h-screen bg-akibaya-dark-indigo text-white">
      <Navbar />

      {/* Hero Section */}
      <section className="py-20 relative overflow-hidden pt-24">
        {/* Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-32 h-32 bg-akibaya-neon-pink/10 rounded-full blur-xl"></div>
          <div className="absolute bottom-20 right-10 w-48 h-48 bg-akibaya-cyan-blue/10 rounded-full blur-xl"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center animate-slide-up">
            <h1 className="text-4xl md:text-6xl font-orbitron font-bold mb-6 gradient-text-akibaya">
              About Akibaya
            </h1>
            <p className="text-xl md:text-2xl text-akibaya-soft-grey max-w-3xl mx-auto leading-relaxed">
              Bangladesh's First Dedicated Anime Wallpaper Brand
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-akibaya-dark-grey-blue/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              {/* Anime-inspired illustration */}
              <Card className="bg-gradient-to-br from-akibaya-neon-pink/20 to-akibaya-cyan-blue/20 border-akibaya-neon-pink/20">
                <CardContent className="p-8 text-center">
                  <Heart className="text-6xl mb-4 text-akibaya-neon-pink mx-auto" />
                  <h3 className="text-2xl font-orbitron font-bold text-white mb-4">
                    Made by Fans, for Fans
                  </h3>
                  <p className="text-akibaya-soft-grey">
                    Every design is crafted with the passion and attention to detail that only true anime enthusiasts can provide.
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="animate-slide-up">
              <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-6 text-white">
                Our Story
              </h2>
              <div className="text-akibaya-soft-grey text-lg leading-relaxed space-y-6">
                <p>
                  Anime isn't just something we watch — it's a part of who we are. But when we looked around, there was nowhere in Bangladesh that truly got it. No one was selling anime wallpapers. No custom sizing. No easy way to bring anime into your personal space.
                </p>
                <p>
                  So we built <span className="text-akibaya-neon-pink font-semibold">Akibaya</span>.
                </p>
                <p>
                  We're one of the very first in the country to offer anime-themed custom wallpapers, along with stickers, printed manga, and more — all crafted with fans in mind.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-4 text-white">
              What We Stand For
            </h2>
            <p className="text-akibaya-soft-grey text-lg">Our commitment to the anime community</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center group">
                <Card className={`bg-akibaya-dark-grey-blue/80 border-akibaya-dark-grey-blue ${value.borderColor} transition-all duration-300 transform hover:scale-105`}>
                  <CardContent className="p-8">
                    <value.icon className={`${value.color} text-4xl mb-4 ${value.hoverColor} transition-colors duration-300 mx-auto`} />
                    <h3 className="text-xl font-orbitron font-semibold mb-3 text-white">
                      {value.title}
                    </h3>
                    <p className="text-akibaya-soft-grey leading-relaxed">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-akibaya-dark-grey-blue/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-8 text-white">
            Our Mission
          </h2>
          <div className="text-xl text-akibaya-soft-grey leading-relaxed mb-8">
            <p className="mb-6">
              Whether you want your entire wall to scream{" "}
              <span className="text-akibaya-neon-pink font-semibold">"Attack on Titan"</span>{" "}
              or you're just looking for some{" "}
              <span className="text-akibaya-cyan-blue font-semibold">Jujutsu Kaisen</span> sticker flair —
              we're here to help you live your anime truth.
            </p>
            <p className="text-2xl font-orbitron font-semibold gradient-text-akibaya">
              Live Your Anime Truth.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-4 text-white">
              Get in Touch
            </h2>
            <p className="text-akibaya-soft-grey text-lg">Ready to start your anime transformation? Let's connect!</p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="space-y-8">
              {contactLinks.map((link, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className={`${link.bgColor} p-3 rounded-lg`}>
                    <link.icon className={`${link.color} text-2xl`} />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-1">{link.title}</h3>
                    <p className="text-akibaya-soft-grey mb-2">{link.description}</p>
                    <a
                      href={link.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`${link.color} hover:text-white transition-colors duration-300 font-medium inline-flex items-center`}
                    >
                      {link.label === "WhatsApp" && "+880 162 985 7483"}
                      {link.label === "Facebook" && "@SiteLagbeBD"}
                      {link.label === "Email" && "akibaya442@gmail.com"}
                      {link.label === "Messenger" && "Direct Message"}
                      <ExternalLink className="ml-1 h-3 w-3" />
                    </a>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA */}
            <Card className="bg-gradient-to-br from-akibaya-dark-grey-blue to-akibaya-dark-indigo border-akibaya-neon-pink/20">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-orbitron font-bold mb-4 text-white">Ready to Start?</h3>
                <p className="text-akibaya-soft-grey mb-8 leading-relaxed">
                  Transform your space with your favorite anime characters. Upload your artwork and let us bring it to life!
                </p>
                <Link href="/order">
                  <Button className="px-8 py-4 gradient-bg-akibaya rounded-full font-orbitron font-bold text-lg text-white hover:shadow-lg hover:shadow-primary/25 transition-all duration-300 transform hover:scale-105">
                    Create Your Order
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
