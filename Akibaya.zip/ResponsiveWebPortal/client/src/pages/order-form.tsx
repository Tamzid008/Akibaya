import { useState, useRef, useCallback } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import { uploadToImageKit, validateImageFile } from "@/lib/imagekit";
import { submitOrder } from "@/lib/api";
import { 
  Upload, 
  X, 
  Tags, 
  Ruler, 
  User, 
  Receipt,
  Loader2,
  CloudUpload,
  Wallpaper,
  Sticker
} from "lucide-react";

const formSchema = z.object({
  customerName: z.string().min(1, "Name is required").max(100),
  customerPhone: z.string().min(10, "Phone number must be at least 10 digits").max(20),
  customerEmail: z.string().email("Please enter a valid email address"),
  customerAddress: z.string().min(5, "Address must be at least 5 characters").max(500),
  notes: z.string().max(1000).optional(),
});

interface ProductConfig {
  type: 'Wallpaper' | 'Sticker';
  length: number;
  width: number;
  quantity: number;
  unit: 'Feet' | 'Inch';
  price: number;
}

export default function OrderForm() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // State management
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string>("");
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [productConfigs, setProductConfigs] = useState<ProductConfig[]>([]);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      customerName: "",
      customerPhone: "",
      customerEmail: "",
      customerAddress: "",
      notes: "",
    },
  });

  // Calculate item price
  const calculateItemPrice = (config: ProductConfig): number => {
    const area = config.length * config.width;
    return Math.round(area * config.price * config.quantity);
  };

  // Calculate subtotal price
  const calculateSubtotal = (): number => {
    return productConfigs.reduce((sum, config) => sum + calculateItemPrice(config), 0);
  };

  // Calculate total price including delivery
  const calculateTotalPrice = (): number => {
    const subtotal = calculateSubtotal();
    return subtotal > 0 ? subtotal + 60 : 0; // Add 60 BDT delivery charge
  };

  // Handle file upload
  const handleFileUpload = useCallback(async (file: File) => {
    const validation = validateImageFile(file);
    if (!validation.valid) {
      toast({
        title: "Invalid file",
        description: validation.error,
        variant: "destructive",
      });
      return;
    }

    // Show preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewUrl(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    // Upload to ImageKit
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      // Simulate progress for better UX
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => Math.min(prev + 10, 90));
      }, 200);

      const response = await uploadToImageKit(file);
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      setUploadedImageUrl(response.url);
      
      toast({
        title: "Upload successful",
        description: "Your image has been uploaded successfully!",
      });
    } catch (error) {
      console.error("Upload failed:", error);
      toast({
        title: "Upload failed",
        description: "Failed to upload image. Please try again.",
        variant: "destructive",
      });
      resetImageUpload();
    } finally {
      setIsUploading(false);
      setTimeout(() => setUploadProgress(0), 2000);
    }
  }, [toast]);

  // Reset image upload
  const resetImageUpload = () => {
    setUploadedImageUrl("");
    setPreviewUrl("");
    setIsUploading(false);
    setUploadProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Handle drag and drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  };

  // Handle product type selection
  const handleProductTypeChange = (type: string, checked: boolean) => {
    if (checked) {
      setSelectedTypes(prev => [...prev, type]);
      setProductConfigs(prev => [
        ...prev,
        {
          type: type as 'Wallpaper' | 'Sticker',
          length: 1,
          width: 1,
          quantity: 1,
          unit: type === 'Wallpaper' ? 'Feet' : 'Inch',
          price: type === 'Wallpaper' ? 60 : 20,
        },
      ]);
    } else {
      setSelectedTypes(prev => prev.filter(t => t !== type));
      setProductConfigs(prev => prev.filter(config => config.type !== type));
    }
  };

  // Update product config
  const updateProductConfig = (index: number, field: keyof ProductConfig, value: number) => {
    setProductConfigs(prev => 
      prev.map((config, i) => 
        i === index ? { ...config, [field]: Math.max(0.1, value) } : config
      )
    );
  };

  // Submit order mutation
  const submitOrderMutation = useMutation({
    mutationFn: submitOrder,
    onSuccess: () => {
      setLocation("/success");
    },
    onError: (error) => {
      console.error("Order submission error:", error);
      toast({
        title: "Order submission failed",
        description: "Failed to submit your order. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Form submission
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (!uploadedImageUrl) {
      toast({
        title: "Image required",
        description: "Please upload an image before submitting your order.",
        variant: "destructive",
      });
      return;
    }

    if (productConfigs.length === 0) {
      toast({
        title: "Product selection required",
        description: "Please select at least one product type.",
        variant: "destructive",
      });
      return;
    }

    // Submit each configuration as a separate order
    for (const config of productConfigs) {
      const itemPrice = calculateItemPrice(config);
      const deliveryCharge = 60;
      const totalWithDelivery = itemPrice + deliveryCharge;
      
      await submitOrderMutation.mutateAsync({
        imageUrl: uploadedImageUrl,
        productType: config.type,
        length: config.length,
        width: config.width,
        unit: config.unit,
        quantity: config.quantity,
        totalPrice: totalWithDelivery,
        name: values.customerName,
        phone: values.customerPhone,
        email: values.customerEmail,
        address: values.customerAddress,
        notes: values.notes,
      });
    }
  };

  const isFormValid = uploadedImageUrl && productConfigs.length > 0 && form.formState.isValid;

  return (
    <div className="min-h-screen bg-akibaya-dark-indigo text-white">
      <Navbar />
      
      <section className="py-12 min-h-screen pt-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-orbitron font-bold mb-4 gradient-text-akibaya">
              Create Your Order
            </h1>
            <p className="text-akibaya-soft-grey text-lg">
              Upload your anime artwork and customize your perfect wallpaper or sticker
            </p>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <Card className="bg-akibaya-dark-grey-blue/80 border-akibaya-dark-grey-blue">
                <CardContent className="p-8">
                  {/* Image Upload Section */}
                  <div className="mb-8">
                    <Label className="text-white font-semibold mb-4 text-lg flex items-center">
                      <Upload className="text-akibaya-neon-pink mr-2" />
                      Upload Your Anime Image
                    </Label>

                    {!previewUrl ? (
                      <div
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-dashed border-akibaya-dark-grey-blue hover:border-akibaya-neon-pink transition-all duration-300 rounded-xl p-8 text-center cursor-pointer bg-akibaya-dark-indigo/50 hover:bg-akibaya-dark-indigo/70"
                      >
                        <CloudUpload className="text-4xl text-akibaya-soft-grey mb-4 mx-auto" />
                        <p className="text-akibaya-soft-grey mb-2">
                          <span className="font-semibold text-white">Click to upload</span> or drag and drop
                        </p>
                        <p className="text-sm text-akibaya-soft-grey">JPG, PNG, WebP up to 10MB</p>
                        <input
                          ref={fileInputRef}
                          type="file"
                          className="hidden"
                          accept="image/jpeg,image/png,image/webp"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleFileUpload(file);
                          }}
                        />
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <img
                          src={previewUrl}
                          alt="Preview"
                          className="max-w-full h-48 object-cover rounded-xl mx-auto border border-akibaya-neon-pink/30"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          onClick={resetImageUpload}
                          className="text-akibaya-neon-pink hover:text-white transition-colors duration-300"
                        >
                          <X className="mr-1 h-4 w-4" />
                          Remove Image
                        </Button>
                      </div>
                    )}

                    {isUploading && (
                      <div className="mt-4">
                        <div className="bg-akibaya-dark-indigo rounded-full h-2">
                          <div
                            className="gradient-bg-akibaya h-2 rounded-full transition-all duration-300"
                            style={{ width: `${uploadProgress}%` }}
                          ></div>
                        </div>
                        <p className="text-sm text-akibaya-soft-grey mt-2">
                          Uploading... {uploadProgress}%
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Product Type Selection */}
                  <div className="mb-8">
                    <Label className="text-white font-semibold mb-4 text-lg flex items-center">
                      <Tags className="text-akibaya-cyan-blue mr-2" />
                      Product Type
                    </Label>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="relative">
                        <Card className={`cursor-pointer transition-all duration-300 ${
                          selectedTypes.includes('Wallpaper')
                            ? 'border-akibaya-neon-pink bg-akibaya-neon-pink/10'
                            : 'border-akibaya-dark-grey-blue hover:border-akibaya-neon-pink/50'
                        }`}>
                          <CardContent className="p-6">
                            <div className="flex items-center space-x-4">
                              <Checkbox
                                checked={selectedTypes.includes('Wallpaper')}
                                onCheckedChange={(checked) => 
                                  handleProductTypeChange('Wallpaper', checked as boolean)
                                }
                              />
                              <Wallpaper className="text-akibaya-neon-pink text-2xl" />
                              <div>
                                <h3 className="font-semibold text-white">Wallpaper</h3>
                                <p className="text-sm text-akibaya-soft-grey">৳60 per sq ft</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>

                      <div className="relative">
                        <Card className={`cursor-pointer transition-all duration-300 ${
                          selectedTypes.includes('Sticker')
                            ? 'border-akibaya-cyan-blue bg-akibaya-cyan-blue/10'
                            : 'border-akibaya-dark-grey-blue hover:border-akibaya-cyan-blue/50'
                        }`}>
                          <CardContent className="p-6">
                            <div className="flex items-center space-x-4">
                              <Checkbox
                                checked={selectedTypes.includes('Sticker')}
                                onCheckedChange={(checked) => 
                                  handleProductTypeChange('Sticker', checked as boolean)
                                }
                              />
                              <Sticker className="text-akibaya-cyan-blue text-2xl" />
                              <div>
                                <h3 className="font-semibold text-white">Sticker</h3>
                                <p className="text-sm text-akibaya-soft-grey">৳20 per sq inch</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </div>

                  {/* Dimensions Section */}
                  {productConfigs.length > 0 && (
                    <div className="mb-8">
                      <Label className="text-white font-semibold mb-4 text-lg flex items-center">
                        <Ruler className="text-akibaya-neon-pink mr-2" />
                        Dimensions & Quantity
                      </Label>

                      <div className="space-y-4">
                        {productConfigs.map((config, index) => (
                          <Card key={index} className="bg-akibaya-dark-indigo/50 border-akibaya-dark-grey-blue">
                            <CardContent className="p-6">
                              <h4 className="text-white font-semibold mb-4 flex items-center">
                                {config.type === 'Wallpaper' ? (
                                  <Wallpaper className="text-akibaya-neon-pink mr-2" />
                                ) : (
                                  <Sticker className="text-akibaya-cyan-blue mr-2" />
                                )}
                                {config.type}
                              </h4>

                              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div>
                                  <Label className="text-akibaya-soft-grey mb-2">
                                    Length ({config.unit})
                                  </Label>
                                  <Input
                                    type="number"
                                    min="0.1"
                                    step="0.1"
                                    value={config.length}
                                    onChange={(e) => 
                                      updateProductConfig(index, 'length', parseFloat(e.target.value) || 0.1)
                                    }
                                    className="bg-akibaya-dark-grey-blue border-akibaya-dark-grey-blue text-white focus:border-akibaya-neon-pink"
                                  />
                                </div>

                                <div>
                                  <Label className="text-akibaya-soft-grey mb-2">
                                    Width ({config.unit})
                                  </Label>
                                  <Input
                                    type="number"
                                    min="0.1"
                                    step="0.1"
                                    value={config.width}
                                    onChange={(e) => 
                                      updateProductConfig(index, 'width', parseFloat(e.target.value) || 0.1)
                                    }
                                    className="bg-akibaya-dark-grey-blue border-akibaya-dark-grey-blue text-white focus:border-akibaya-cyan-blue"
                                  />
                                </div>

                                <div>
                                  <Label className="text-akibaya-soft-grey mb-2">Quantity</Label>
                                  <Input
                                    type="number"
                                    min="1"
                                    value={config.quantity}
                                    onChange={(e) => 
                                      updateProductConfig(index, 'quantity', parseInt(e.target.value) || 1)
                                    }
                                    className="bg-akibaya-dark-grey-blue border-akibaya-dark-grey-blue text-white focus:border-akibaya-neon-pink"
                                  />
                                </div>

                                <div>
                                  <Label className="text-akibaya-soft-grey mb-2">Total</Label>
                                  <div className={`px-3 py-2 bg-akibaya-dark-grey-blue border border-akibaya-dark-grey-blue rounded-lg font-semibold ${
                                    config.type === 'Wallpaper' ? 'text-akibaya-neon-pink' : 'text-akibaya-cyan-blue'
                                  }`}>
                                    ৳{calculateItemPrice(config)}
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Customer Information */}
                  <div className="mb-8">
                    <h3 className="text-white font-semibold mb-4 text-lg flex items-center">
                      <User className="text-akibaya-cyan-blue mr-2" />
                      Your Information
                    </h3>

                    <div className="grid md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="customerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-akibaya-soft-grey">Full Name *</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                className="bg-akibaya-dark-indigo border-akibaya-dark-grey-blue text-white placeholder-akibaya-soft-grey focus:border-akibaya-neon-pink"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="customerPhone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-akibaya-soft-grey">Phone Number *</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                type="tel"
                                className="bg-akibaya-dark-indigo border-akibaya-dark-grey-blue text-white placeholder-akibaya-soft-grey focus:border-akibaya-cyan-blue"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="customerEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-akibaya-soft-grey">Email Address *</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                type="email"
                                className="bg-akibaya-dark-indigo border-akibaya-dark-grey-blue text-white placeholder-akibaya-soft-grey focus:border-akibaya-neon-pink"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="customerAddress"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-akibaya-soft-grey">Address *</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                className="bg-akibaya-dark-indigo border-akibaya-dark-grey-blue text-white placeholder-akibaya-soft-grey focus:border-akibaya-cyan-blue"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="mt-6">
                      <FormField
                        control={form.control}
                        name="notes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-akibaya-soft-grey">Special Notes (Optional)</FormLabel>
                            <FormControl>
                              <Textarea
                                {...field}
                                rows={3}
                                className="bg-akibaya-dark-indigo border-akibaya-dark-grey-blue text-white placeholder-akibaya-soft-grey focus:border-akibaya-neon-pink resize-none"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  {/* Order Summary */}
                  {productConfigs.length > 0 && (
                    <Card className="mb-8 bg-akibaya-dark-indigo/50 border-akibaya-neon-pink/20">
                      <CardContent className="p-6">
                        <h3 className="text-white font-semibold mb-4 text-lg flex items-center">
                          <Receipt className="text-akibaya-neon-pink mr-2" />
                          Order Summary
                        </h3>
                        <div className="space-y-3">
                          {productConfigs.map((config, index) => (
                            <div key={index} className="flex justify-between items-center py-2 border-b border-akibaya-dark-grey-blue last:border-b-0">
                              <div>
                                <span className="text-white font-medium">{config.type}</span>
                                <span className="text-akibaya-soft-grey text-sm ml-2">
                                  ({config.length}×{config.width} {config.unit.toLowerCase()}) × {config.quantity}
                                </span>
                              </div>
                              <span className={`font-semibold ${
                                config.type === 'Wallpaper' ? 'text-akibaya-neon-pink' : 'text-akibaya-cyan-blue'
                              }`}>
                                ৳{calculateItemPrice(config)}
                              </span>
                            </div>
                          ))}
                        </div>
                        <div className="border-t border-akibaya-dark-grey-blue mt-4 pt-4 space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-akibaya-soft-grey">Subtotal:</span>
                            <span className="text-white font-semibold">৳{calculateSubtotal()}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-akibaya-soft-grey">Delivery Charge:</span>
                            <span className="text-white font-semibold">৳60</span>
                          </div>
                          <div className="border-t border-akibaya-dark-grey-blue pt-2">
                            <div className="flex justify-between items-center">
                              <span className="text-lg font-semibold text-white">Total Amount:</span>
                              <span className="text-2xl font-bold text-akibaya-neon-pink">
                                ৳{calculateTotalPrice()}
                              </span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    disabled={!isFormValid || submitOrderMutation.isPending}
                    className="w-full py-4 gradient-bg-akibaya rounded-xl font-orbitron font-bold text-lg text-white disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg hover:shadow-primary/25 transition-all duration-300 transform hover:scale-[1.02]"
                  >
                    {submitOrderMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2 h-4 w-4" />
                        Submit Order
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </form>
          </Form>
        </div>
      </section>

      <Footer />
    </div>
  );
}
