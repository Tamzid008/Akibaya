import { useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import { 
  Check, 
  Mail, 
  Phone, 
  Wand2, 
  Truck, 
  Home, 
  Plus,
  Info
} from "lucide-react";
import { FaWhatsapp, FaFacebook, FaEnvelope } from "react-icons/fa";

export default function Success() {
  useEffect(() => {
    // Create confetti effect
    const createConfetti = () => {
      const colors = ['#FF4F8B', '#00E0FF', '#FFFFFF'];
      const confettiCount = 50;

      for (let i = 0; i < confettiCount; i++) {
        const confetti = document.createElement('div');
        confetti.style.position = 'fixed';
        confetti.style.left = Math.random() * 100 + 'vw';
        confetti.style.top = '-10px';
        confetti.style.width = '10px';
        confetti.style.height = '10px';
        confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        confetti.style.borderRadius = '50%';
        confetti.style.pointerEvents = 'none';
        confetti.style.zIndex = '1000';
        confetti.style.animation = `fall ${3 + Math.random() * 2}s linear forwards`;

        document.body.appendChild(confetti);

        // Remove confetti after animation
        setTimeout(() => {
          if (confetti.parentNode) {
            confetti.parentNode.removeChild(confetti);
          }
        }, 5000);
      }
    };

    // Add CSS for confetti animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes fall {
        to {
          transform: translateY(100vh) rotate(360deg);
          opacity: 0;
        }
      }
    `;
    document.head.appendChild(style);

    // Trigger confetti
    setTimeout(createConfetti, 1000);

    // Cleanup
    return () => {
      if (style.parentNode) {
        style.parentNode.removeChild(style);
      }
    };
  }, []);

  const nextSteps = [
    {
      icon: Mail,
      title: "Confirmation Email",
      description: "We'll send you a detailed confirmation with your order details within the next few hours.",
      color: "text-akibaya-neon-pink",
      bgColor: "bg-akibaya-neon-pink/20",
    },
    {
      icon: Phone,
      title: "Personal Contact",
      description: "Our team will reach out to discuss any final details and delivery arrangements.",
      color: "text-akibaya-cyan-blue",
      bgColor: "bg-akibaya-cyan-blue/20",
    },
    {
      icon: Wand2,
      title: "Production Magic",
      description: "We'll transform your anime artwork into stunning wallpapers and stickers with perfect quality.",
      color: "text-akibaya-neon-pink",
      bgColor: "bg-akibaya-neon-pink/20",
    },
    {
      icon: Truck,
      title: "Fast Delivery",
      description: "Your anime dreams will be delivered to your doorstep with care and excitement!",
      color: "text-akibaya-cyan-blue",
      bgColor: "bg-akibaya-cyan-blue/20",
    },
  ];

  const contactLinks = [
    {
      href: "https://wa.me/+8801629857483",
      icon: FaWhatsapp,
      label: "WhatsApp",
      hoverColor: "hover:text-akibaya-neon-pink",
    },
    {
      href: "https://www.facebook.com/SiteLagbeBD/",
      icon: FaFacebook,
      label: "Facebook",
      hoverColor: "hover:text-akibaya-cyan-blue",
    },
    {
      href: "mailto:akibaya442@gmail.com",
      icon: FaEnvelope,
      label: "Email",
      hoverColor: "hover:text-akibaya-neon-pink",
    },
  ];

  return (
    <div className="min-h-screen bg-akibaya-dark-indigo text-white">
      <Navbar />

      {/* Success Section */}
      <section className="min-h-screen flex items-center justify-center relative overflow-hidden py-20 pt-24">
        {/* Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-32 h-32 bg-akibaya-neon-pink/10 rounded-full blur-xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-48 h-48 bg-akibaya-cyan-blue/10 rounded-full blur-xl animate-pulse [animation-delay:1s]"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-r from-akibaya-neon-pink/5 to-akibaya-cyan-blue/5 rounded-full blur-3xl"></div>
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            {/* Success Icon */}
            <div className="animate-bounce-in mb-8">
              <div className="inline-flex items-center justify-center w-32 h-32 gradient-bg-akibaya rounded-full mb-6">
                <Check className="text-white text-4xl" />
              </div>
            </div>

            {/* Success Message */}
            <div className="animate-fade-in [animation-delay:0.5s]">
              <h1 className="text-4xl md:text-6xl font-orbitron font-bold mb-6">
                <span className="gradient-text-akibaya">Order Received!</span>
              </h1>

              <p className="text-xl md:text-2xl text-akibaya-soft-grey mb-8 leading-relaxed max-w-2xl mx-auto">
                We'll contact you shortly to confirm your amazing anime order.
              </p>
            </div>

            {/* Order Details */}
            <Card className="animate-fade-in bg-akibaya-dark-grey-blue/80 border-akibaya-neon-pink/20 mb-8 max-w-2xl mx-auto [animation-delay:1s]">
              <CardContent className="p-8">
                <h2 className="text-2xl font-orbitron font-bold mb-6 text-white">What Happens Next?</h2>

                <div className="space-y-6 text-left">
                  {nextSteps.map((step, index) => (
                    <div key={index} className="flex items-start space-x-4">
                      <div className={`${step.bgColor} p-3 rounded-lg flex-shrink-0`}>
                        <step.icon className={`${step.color}`} />
                      </div>
                      <div>
                        <h3 className="text-white font-semibold mb-1">{step.title}</h3>
                        <p className="text-akibaya-soft-grey">{step.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Cancel Information */}
            <Card className="animate-fade-in bg-akibaya-dark-indigo/50 border-akibaya-dark-grey-blue/50 mb-8 max-w-2xl mx-auto [animation-delay:1.5s]">
              <CardContent className="p-6">
                <p className="text-akibaya-soft-grey text-sm flex items-start">
                  <Info className="text-akibaya-cyan-blue mr-2 h-4 w-4 mt-0.5 flex-shrink-0" />
                  Need to cancel your order? Simply reply to our confirmation email or contact us directly.
                  We're here to make sure you get exactly what you want!
                </p>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="animate-fade-in flex flex-col sm:flex-row gap-4 justify-center items-center mb-12 [animation-delay:2s]">
              <Link href="/">
                <Button className="px-8 py-4 gradient-bg-akibaya rounded-full font-orbitron font-bold text-lg text-white hover:shadow-lg hover:shadow-primary/25 transition-all duration-300 transform hover:scale-105">
                  <Home className="mr-2 h-4 w-4" />
                  Back to Home
                </Button>
              </Link>

              <Link href="/order">
                <Button
                  variant="outline"
                  className="px-8 py-4 border-2 border-akibaya-cyan-blue text-akibaya-cyan-blue rounded-full font-semibold hover:bg-akibaya-cyan-blue hover:text-akibaya-dark-indigo transition-all duration-300 transform hover:scale-105"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Create Another Order
                </Button>
              </Link>
            </div>

            {/* Contact Info */}
            <div className="animate-fade-in [animation-delay:2.5s]">
              <p className="text-akibaya-soft-grey mb-4">Questions? Get in touch with us:</p>
              <div className="flex justify-center space-x-6">
                {contactLinks.map((link, index) => (
                  <a
                    key={index}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`text-akibaya-soft-grey ${link.hoverColor} transition-colors duration-300 text-2xl`}
                    aria-label={link.label}
                  >
                    <link.icon />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
