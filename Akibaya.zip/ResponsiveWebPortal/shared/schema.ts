import { pgTable, text, serial, integer, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  imageUrl: text("image_url").notNull(),
  productType: text("product_type").notNull(), // 'Wallpaper' or 'Sticker'
  length: decimal("length", { precision: 8, scale: 2 }).notNull(),
  width: decimal("width", { precision: 8, scale: 2 }).notNull(),
  unit: text("unit").notNull(), // 'Feet' or 'Inch'
  quantity: integer("quantity").notNull().default(1),
  totalPrice: integer("total_price").notNull(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerAddress: text("customer_address").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertOrderSchema = createInsertSchema(orders, {
  length: z.number().positive().max(1000),
  width: z.number().positive().max(1000),
  quantity: z.number().int().positive().max(100),
  totalPrice: z.number().int().positive(),
  customerName: z.string().min(1).max(100),
  customerPhone: z.string().min(10).max(20),
  customerEmail: z.string().email(),
  customerAddress: z.string().min(5).max(500),
  notes: z.string().max(1000).optional(),
}).omit({
  id: true,
  createdAt: true,
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;
